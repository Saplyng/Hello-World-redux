from kivy.uix.checkbox import CheckBox


class CustomCheckBox(CheckBox):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
